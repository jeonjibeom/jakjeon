package com.naver.erp;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
//LoginController 클래스 선언.
//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	/*
	스프링에서 관용적으로 Controller 라는 단어가 들어간 클래스는
	URL주소 접속시 대응해서 호출되는 메소드를 소유하고 있다.
	클래스 이름 앞에는 @Controller라는 어노테이션이 붙는다.
	
	클래스 내부의 URL주소 접속시 호출되는 메소드명 앞에는
		@RequestMapping라는 어노테이션이 붙는다.
		
		------------------------------------------
		@Controller 어노테이션이 붙은 클래스 특징
		------------------------------------------
			(1) 스프링프레임워크가 알아서 객체를 생성하고 관리한다.
			(2) URL주소 접속 시 대응해서 호출되는 메소드를 소유하고 있다.
	*/
@Controller
public class LoginController {
	
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// URL 주소 /loginForm.do 로 접근하면 호출되는 메소드 선언.
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
		/*
		URL주소에 대응하여 호출되려면 메소드 앞에
		@RequestMapping(value="포트번호 이후 주소") 이라는 어노테이션을 붙여야한다.
		--------------------------------------------------------------
			<주의> @RequestMapping이 붙은 메소드의 이름은  개발자 재량이다.
					될 수 있는대로 URL주소의 의도를 살리는 메소드 이름을 주는것이 좋다.
		--------------------------------------------------------------
		 
		*/
	@RequestMapping(value="/loginForm.do")
	public ModelAndView loginForm() {
		//[ModelAndView 객체]  생성.
		ModelAndView mav = new ModelAndView();
		//[ModelAndView 객체]의 setViewName 메소드를 호출하여
		//[호출할 JSP페이지명]을 문자로 저장.
			//-----------------------------------------------
			/*
			[호출할 JSP페이지명]앞에 붙는 위치 경로는
			application.properties 에서
			spring.mvc.view.prefix=/WEB-INF/views/ 	에 설정
			[호출할 JSP페이지명] 뒤에 붙는 확장자는
			application.properties 에서
			spring.mvc.view.suffix=jsp		에 설정한다. 근데 공부한느 입장에서는 생략
			// <참고> 기본적으로 저장경로에서 webapp폴터까지는 자동으로 찾아간다.
			*/
		mav.setViewName("loginForm.jsp");
		//[ModelAndView 객체] 리턴.
			//[ModelAndView 객체] 객체를 리턴하면 바로 JSP페이지를 리턴한다.
		return mav;
	}
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	//URL주소 /loginProc.do로 접근하면 호출되는 메소드 선언
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
		//메소드 앞에
		//@RequestMapping(~,~,produces="application/json;charset=UTF-8")하고
		//@ResponseBody가 붙으면 리턴하는 데이터가 웹 브라우저에게 전송된다.
	@RequestMapping(
			value="/loginProc.do"
			,method=RequestMethod.POST
			,produces="application/json;charset=UTF-8"
	)
	@ResponseBody
	public int loginProc() {
		return 1;
	}
	
	
}
